




### 예시 문제


블로그 (실버3)
https://www.acmicpc.net/problem/21921

