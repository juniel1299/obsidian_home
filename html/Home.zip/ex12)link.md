# 링크
- 쌍태그, 혼합형
1. Link
2. Anchor

## a.href
- 이동할 URL

```html
  <a href="http://www.naver.com" class="">네이버</a>
      <a href="ex11_list.html"></a> <!-- 상대경로 -->
```

## a.target
- 열거형
1. \_blank
	- 
2. \_self(default)
	- 기존 창을 닫고 열음
1. \_parent
2. \_top
  e. 프레임명

## 앵커
```html
<h2><a name="a1" id="a1">내용 </a></h2>
```
