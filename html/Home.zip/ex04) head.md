# head태그

- 브라우저에게 전달할 문서의 정보를 담는 컨테이너 태그

head 자식 태그

1. meta
	- 페이지와 관련된 여러가지 정보를 담는다.
```html

<meta name="author" content="홍길동"> 작성자 개발자
<meta name="generator" content = "Eclipse 2022-06"> 작성툴
<meta name="keywords" content="HTML,수업예제,태그"> 키워드
<meta name="description" content="head 태그를 배우는 예제입니다.">

```
2. title
	- 문서 제목을 작성하는 위치
	- 반드시 기입한다 ***
	- 역할
		a. 브라우저의 타이틀바(제목표시줄)에 출력된다.
		b. 검색 사이트의 결과 제목으로 사용된다 + 검색 정보 수집 대상
		c. 브라우저의 북마크의 제목으로 사용된다. 



2. style
3. script
