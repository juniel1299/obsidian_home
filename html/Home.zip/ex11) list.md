- ol + li
	- ol : ordered list , 순서가 있는 목록
	- li : list item 항목

- ul + li
	- ul : unordered list 순서가 없는 목록
	- li : list item 항목

- dl + dt + dd
	- 용어 정의 목록
	- dl : Definition List 정의 목록
	- dt : Definition Term 용어
	- dd : Definition Description 용어 설명 
```html
<style>
ol > li, ul > li {

            display : inline;

        }

</style>

```