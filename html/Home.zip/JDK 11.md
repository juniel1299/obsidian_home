JDK 11 DownLoad -> window 버전 다운   


환경변수 
javahome -> jdk-21 에서 jdk-11 변경  후 닫기 다시 실행 -> bin 자동으로 11 변환  



## tomcat 설치
https://tomcat.apache.org/
download 8.5.99 다운 



## 새 프로젝트

File -> New -> Dynamic Web Project


Window -> Preference -> encoding -> UTF-8로 다 변경 



## tomcat 
C:\\class\\dev\\apache-tomcat-8.5.99\\webapps 



## 이클립스 아파치 톰캣 연결
window -> show view -> server -> 톰캣 루트폴더 > add finish

프로젝트 우클릭 >  properties > project Facets > Dynamic web module 버전 3.1 변경 
Dynamic Web Server 3.1 버전 

콘솔창에서 서버 정보 뜸 

## 이클립스 시스템 브라우저 

Window -> Web browser 에서 정리 

