```html
     <h1>물리적 모양</h1><br>

    <b>볼드체</b><br>

    <i>이탤릭체</i><br>

    <u>밑줄언더라인</u> <br>

    <strike>취소선</strike><br>

    H<sub>2밑첨자</sub><br>

    MC<sup>윗첨자</sup><br>

    <big>큰 글자</big><br>

    <small>작은 글자</small><br>

    <tt>타자기 글자</tt> <br>

    <h1>의미를 강조하는 태그</h1> <br>

    <strong>중요한 데이터입니다.</strong> <br>

    <em>중요한데이터</em><br>

    <mark>강조할 때 사용</mark><br>

    <cite>인용 데이터</cite><br>

    <blockquote>인용데이터</blockquote><br>

    <code>int a = 10;</code><br>

    <samp>샘플데이터</samp><br>

    <address>주소데이터</address><br>

    <ins>추가데이터</ins><br>

    <del>삭제된데이터</del><br>

    <s>수정된데이터</s><br>

    <abbr>축약데이터, 약어</abbr><br>

<!-- -->

    <bdo dir="ltr">안녕하세요</bdo><br>

    <bdo dir="rtl">안녕하세요</bdo><br>


```



