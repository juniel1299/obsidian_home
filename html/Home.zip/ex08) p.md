# P 태그

- 문단 태그
- 텍스트 집합
- 쌍태그
- 혼합형

## p.align
- horizontal alignment
- left|center|right|justify

