# Heading \<hn\>

- 제목을 표현하는 태그
- h1부터 h6까지 존재 
- 그냥 # , ## , ###
- 시각적 의미 x 
- 의미 (역할) : 제목 역할 
- 쌍태그, 혼합형
- 검색 엔진이 수집하는 대상



## h1.align 속성
- horizontal alignment 수평 정렬
- left, center, right, justifiy(양쪽 정렬)

시맨틱 웹 (Semantic Web)
